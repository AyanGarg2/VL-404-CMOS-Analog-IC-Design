% Read the CSV file
data = readtable("D:\College Doc\Sem5\analog IC\Analog IC Lab\lab2\tran_fifth_amp.csv");

% Set font name and size to match AC plot style
fontSize = 8;
fontName = 'Times';

% Create figure with controlled size (IEEE column width)
figWidth = 3.5; % inches
figHeight = 2.5;
figure('Units', 'inches', 'Position', [1 1 figWidth figHeight], 'PaperPositionMode', 'auto');

% Plot /VOUT signal vs time
plot(data{:,1}, data{:,2}, 'b-', 'LineWidth', 1.2);
hold on;

% Plot /net1 signal vs time
plot(data{:,3}, data{:,4}, 'r-', 'LineWidth', 1.2);
hold off;

% Axis labels and title with font size and name set
xlabel('Time (seconds)', 'FontSize', fontSize, 'FontName', fontName);
ylabel('Amplitude', 'FontSize', fontSize, 'FontName', fontName);
title('Transient Analysis: Vout and Vin vs Time', 'FontSize', fontSize, 'FontName', fontName);

% Legend with font properties
legend({'Vout', 'Vin'}, 'FontSize', fontSize, 'FontName', fontName, 'Location', 'best');

% Set axes font size and name for ticks
set(gca, 'FontSize', fontSize, 'FontName', fontName);

grid on;

% Export EPS file with no scaling issues
print('-depsc2', '-loose', 'q5_tran.eps');
